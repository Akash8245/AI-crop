import os
import secrets
from datetime import datetime
from functools import wraps

import markdown2
import requests
from flask import (
    Flask,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)


app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(16))

GEMINI_MODEL = "gemini-2.5-flash"
GEMINI_API_KEY = os.environ.get(
    "GEMINI_API_KEY", "AIzaSyAn8H6SePzc1XXSA4xIObV1eHTwQBX4orU"
)
OPEN_WEATHER_API_KEY = os.environ.get(
    "OPEN_WEATHER_API_KEY", "99c8de303df143bed9b3272954e66163"
)
DEFAULT_LAT = os.environ.get("DEFAULT_LAT", "12.9716")
DEFAULT_LON = os.environ.get("DEFAULT_LON", "77.5946")
DEFAULT_CITY = os.environ.get("DEFAULT_CITY", "Bengaluru")

# In-memory user store & insights cache (demo purposes only).
users = {}
user_histories = {}


def login_required(view_func):
    """Basic session gatekeeper for non-production use."""

    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "username" not in session:
            flash("Please log in first ✨", "warning")
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)

    return wrapped


def fetch_weather(lat, lon):
    """Get current weather snapshot for dashboard + prompt conditioning."""
    if not lat or not lon or not OPEN_WEATHER_API_KEY:
        return {}

    try:
        response = requests.get(
            "https://api.openweathermap.org/data/2.5/weather",
            params={
                "lat": lat,
                "lon": lon,
                "units": "metric",
                "appid": OPEN_WEATHER_API_KEY,
            },
            timeout=15,
        )
        response.raise_for_status()
        data = response.json()
        main = data.get("main", {})
        weather = data.get("weather", [{}])[0]
        wind = data.get("wind", {})
        return {
            "city": data.get("name") or "",
            "temp_c": main.get("temp"),
            "humidity": main.get("humidity"),
            "conditions": weather.get("description", "").title(),
            "icon": weather.get("icon"),
            "wind": wind.get("speed"),
            "lat": lat,
            "lon": lon,
        }
    except requests.RequestException:
        return {}


def generate_crop_plan(crop_name, land_size, location_name, weather_snapshot):
    """Call Gemini to craft a tailored crop timing plan."""
    base_url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
    )
    weather_line = (
        f"Weather now in {location_name}: "
        f"{weather_snapshot.get('temp_c', 'N/A')}°C, "
        f"humidity {weather_snapshot.get('humidity', 'N/A')}%, "
        f"conditions {weather_snapshot.get('conditions', 'N/A')}."
        if weather_snapshot
        else "Weather data unavailable."
    )
    prompt = f"""
    You are AgroPulse, an elite agronomy strategist. Given:
    - Crop: {crop_name}
    - Land size (acres or hectares): {land_size}
    - Location: {location_name}
    - {weather_line}

    Respond ONLY in Markdown with these sections (do not skip):
    ## Market-Timed Sowing Window
    Summarize the best 2-week sowing window and explain the link to higher market prices.

    ## Weather & Soil Checklist
    Bullet list blending current weather with soil preparation steps.

    ## Demand Outlook & Alternatives
    Outline demand vs supply sentiment for {location_name}. If outlook is saturated, recommend two alternative crops with rationale.

    ## Care-to-Harvest Timeline
    Provide a tight timeline (seed, care, harvest checkpoints) aligned to market readiness.

    ## Action Notes
    2-3 crisp action items for the grower.
    Keep the total response under 220 words, no bold syntax in headings.
    """
    try:
        response = requests.post(
            base_url,
            json={
                "contents": [
                    {
                        "parts": [
                            {
                                "text": prompt.strip(),
                            }
                        ]
                    }
                ]
            },
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        return (
            data.get("candidates", [{}])[0]
            .get("content", {})
            .get("parts", [{}])[0]
            .get("text", "No insights available right now.")
        )
    except requests.RequestException as exc:
        return f"Gemini API error: {exc}"


@app.route("/")
def landing():
    return render_template("landing.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "").strip()
        farm_name = request.form.get("farm_name", "").strip()

        if not username or not password:
            flash("Username & password are required.", "danger")
        elif username in users:
            flash("That username already exists.", "warning")
        else:
            users[username] = {"password": password, "farm_name": farm_name}
            user_histories[username] = []
            flash("Account created! Please log in 🌱", "success")
            return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "").strip()

        user = users.get(username)
        if not user or user["password"] != password:
            flash("Invalid credentials, try again.", "danger")
        else:
            session["username"] = username
            flash("Welcome back to AgroPulse!", "success")
            return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Signed out successfully. See you soon!", "info")
    return redirect(url_for("landing"))


@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    username = session["username"]
    result = None

    if request.method == "POST":
        crop = request.form.get("crop_name", "").strip()
        size = request.form.get("land_size", "").strip()
        lat = request.form.get("latitude")
        lon = request.form.get("longitude")
        city_name = request.form.get("city_name", "").strip()
        used_fallback = False

        if not crop or not size:
            flash("Please fill in both crop and land size.", "danger")
        else:
            if not lat or not lon:
                lat = DEFAULT_LAT
                lon = DEFAULT_LON
                used_fallback = True

            weather = fetch_weather(lat, lon)
            location_name = (
                city_name
                or weather.get("city")
                or (DEFAULT_CITY if used_fallback else f"Lat {lat}, Lon {lon}")
            )
            if used_fallback and weather:
                weather.setdefault("city", DEFAULT_CITY)
            if used_fallback and not city_name:
                location_name = DEFAULT_CITY
            insights_md = generate_crop_plan(crop, size, location_name, weather)
            insights_html = markdown2.markdown(
                insights_md,
                extras=["fenced-code-blocks", "tables"],
            )
            result = {
                "crop": crop,
                "land_size": size,
                "location_name": location_name,
                "insights_markdown": insights_md,
                "insights_html": insights_html,
                "weather": weather,
                "timestamp": datetime.utcnow(),
                "lat": lat,
                "lon": lon,
            }
            user_histories.setdefault(username, []).insert(0, result)

    history = user_histories.get(username, [])[:5]
    for item in history:
        if "insights_html" not in item and item.get("insights"):
            item["insights_html"] = markdown2.markdown(
                item["insights"],
                extras=["fenced-code-blocks", "tables"],
            )
        if "location_name" not in item:
            item["location_name"] = item.get("location", "Location not provided")
        if "weather" not in item:
            item["weather"] = {}
    if not result and history:
        result = history[0]

    farm_name = users.get(username, {}).get("farm_name", "AgroPulse Farm")
    current_weather = (result or {}).get("weather") or {}
    return render_template(
        "dashboard.html",
        active_result=result,
        history=history,
        farm_name=farm_name,
        username=username,
        weather=current_weather,
        default_location={"lat": DEFAULT_LAT, "lon": DEFAULT_LON, "city": DEFAULT_CITY},
    )


@app.route("/api/weather")
@login_required
def api_weather():
    lat = request.args.get("lat")
    lon = request.args.get("lon")
    if not lat or not lon:
        return jsonify({"error": "latitude and longitude required"}), 400
    snapshot = fetch_weather(lat, lon)
    if not snapshot:
        return jsonify({"error": "weather unavailable"}), 502
    return jsonify(snapshot)


@app.route("/api/ping")
def health():
    return {"status": "ok"}


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 5321)))

